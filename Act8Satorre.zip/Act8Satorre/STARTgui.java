package Act8Satorre;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class STARTgui implements ActionListener {
    // Properties
    boolean check = false;
    int loadings;
    int greenLoading;
    //================================================= NORMAL USED
    JFrame f, FLoading;
    JPanel pBackBorder, pHeading, pCenter, pOnOff, pDisplayOnOff;
    JLabel LPower, LOn, LOff, LTitle, LTitleName;
    JButton BStart, BOn,BOff, BStudName, BExit;
    Border borderBlack,borderRed, borderGray, borderDarkGray;

    //================================================= FOR DESIGN
    JPanel PDredLeft, PDredRight, PDcBlack, PDcBlue, PDcGreen, PDcRED, PDcRedLeft, PDcRedRight;

    //================================================= Frame for Loading
    JPanel PBackground, PGreen;
    JLabel  LWaiting, LPercent;
    JButton BProceed;

    // CONSTRUCTOR
    // For Starting Frame
    public STARTgui() {
        //========================================================================= BORDER
        borderBlack = BorderFactory.createLineBorder(Color.black, 5);
        borderRed = BorderFactory.createLineBorder(Color.red, 3);
        borderGray = BorderFactory.createLineBorder(Color.gray, 4);
        borderDarkGray = BorderFactory.createLineBorder(Color.gray, 6);

        //========================================================================= FRAME
        f = CreateFrame( 400, 632);
        //========================================================================= PANEL
        pBackBorder = CreatePanel(borderDarkGray,null,0,0,385,593);
        pHeading = CreatePanel(borderRed,Color.black ,25,20,335,70);
        pCenter = CreatePanel(borderBlack, Color.gray,25,150,335,300);
        pOnOff = CreatePanel(null,null ,25,115,150,30);
        pDisplayOnOff = CreatePanel(borderGray,Color.black ,60,2,50,26);

        //========================================================================= LABEL
        LTitleName = CreateLabel("STUDENT NAME", Color.GREEN,false, 30,6,300,60);
        LTitleName.setFont(new Font("Arial", Font.BOLD, 35));
        LTitle =  CreateLabel("ACTIVITY 8", Color.YELLOW,false, 60,6,300,60);
        LTitle.setFont(new Font("Arial", Font.BOLD, 40));
        LOn = CreateLabel("ON", Color.GREEN,false, 15, 0 ,60,26);
        LOff = CreateLabel("OFF", Color.RED,true, 15, 0 ,60,26);
        LPower = CreateLabel("POWER: ", null, true,0, 0 ,80,35);
        LPower.setFont(new Font("Arial", Font.BOLD, 13));

        //========================================================================= BUTTON
        BExit = CreateButton("EXIT",15,borderBlack,Color.ORANGE,152,530,80,30);
        BStudName = CreateButton("STUDENT NAME",15,borderBlack,Color.darkGray,85,200,160,60);
        BStudName.setEnabled(false);
        BStart = CreateButton("START",40,borderBlack,Color.darkGray,40,80,250,100);
        BStart.setEnabled(false);
        BOn = CreateButton("ON",15,borderBlack,Color.GREEN,125,470,60,35);
        BOff = CreateButton("OFF",15,borderBlack,Color.RED,200,470,60,35);

        //========================================================================= DESIGN PANEL
        PDcBlack = CreatePanel(borderBlack, Color.BLACK ,75,0,60,100);
        PDcGreen = CreatePanel(borderBlack, Color.GREEN ,143,0,20,250);
        PDcRED = CreatePanel(borderBlack, Color.RED ,170,0,20,250);
        PDcBlue = CreatePanel(borderBlack, Color.BLUE ,197,0,60,100);

        PDcRedLeft = CreatePanel(borderBlack, Color.DARK_GRAY ,24,10,20,100);
        PDredLeft = CreatePanel(borderBlack, Color.RED ,40,445,70,150);

        PDcRedRight = CreatePanel(borderBlack, Color.DARK_GRAY ,24,10,20,100);
        PDredRight = CreatePanel(borderBlack, Color.RED,275,445,70,150);

        //========================================================================= DISPLAY AND ADD
        AddComponentsFor1stPage();

        f.setVisible(true);
    }

    // For Loading Frame
    public STARTgui(String loading) {
        //========================================================================= BORDERS
        borderBlack = BorderFactory.createLineBorder(Color.BLACK, 5);
        borderDarkGray = BorderFactory.createLineBorder(Color.DARK_GRAY, 6);

        //========================================================================= FRAME
        FLoading = CreateFrame( 500, 300);

        //========================================================================= PANELs
        pHeading = CreatePanel(borderDarkGray,Color.BLACK,15,10,450,50);
        PBackground = CreatePanel(borderBlack,Color.gray,40,100,400,60);
        PGreen = new JPanel();
        PGreen.setBackground(Color.GREEN);

        //========================================================================= LABELs
        LPercent = CreateLabel("LOADING: 0%",Color.BLACK,true,90,16,400,30);
        LPercent.setFont(new Font("Arial", Font.BOLD, 22));
        LTitle =  CreateLabel("LOADING COMPLETE!", Color.GREEN,false, 60,2,500,50);
        LTitle.setFont(new Font("Arial", Font.BOLD, 30));
        LWaiting = CreateLabel("PLEASE WAIT", Color.RED,true, 110,2,500,50);
        LWaiting.setFont(new Font("Arial", Font.BOLD, 35));

        //========================================================================= BUTTON
        BProceed = CreateButton("PROCEED",15,borderBlack,Color.DARK_GRAY,160,200,150,40);
        BProceed.setEnabled(false);

        //========================================================================= APPLY LOADING
        Loading();

        //========================================================================= DISPLAY AND ADD
        AddComponentsForLoadingFrame();
        FLoading.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource() == BOn) {
            check = true;
            updateLabelsAndButton(true);
        }

        if(e.getSource() == BOff){
            check = false;
            updateLabelsAndButton(false);
        }

        if(e.getSource() == BStart){
            f.dispose(); // Exit Frame
            new STARTgui("loading");
        }

        if(e.getSource() == BStudName) {
            showStudentName();
        }

        if(e.getSource() == BExit) {
            if (check) {
                JOptionPane.showMessageDialog(null,
                        "PLEASE TURN IT OFF BEFORE YOU EXIT!"); // You cant exit if the frame is still ON
            } else {
                f.dispose(); // Exit frame
            }
        }

        if(e.getSource() == BProceed) {
            FLoading.dispose(); // Exit Frame
            InsuredCarDemo main = new InsuredCarDemo(); // Calling the Main Class ( object )
            main.MainAct8(); // The main activity
        }
    }

    // This is the Action of Button On and Off
    private void updateLabelsAndButton(boolean isOn) {
        LOn.setVisible(isOn);
        LOff.setVisible(!isOn);
        LTitle.setVisible(isOn);

        // BStart Update
        if (isOn) {
            PDcRedRight.setBackground(Color.YELLOW);
            PDcRedRight.setBorder(borderBlack);
            PDcRedLeft.setBackground(Color.YELLOW);
            PDcRedLeft.setBorder(borderBlack);

            BStudName.setEnabled(true);
            BStudName.setBorder(borderBlack);
            BStudName.setForeground(Color.BLACK);
            BStudName.setBackground(new Color(0, 163, 168));

            BStart.setEnabled(true);
            BStart.setBorder(borderBlack);
            BStart.setForeground(Color.BLACK);
            BStart.setBackground(new Color(0, 163, 168));
        } else {
            PDcRedRight.setBackground(Color.DARK_GRAY);
            PDcRedLeft.setBackground(Color.DARK_GRAY);

            BStudName.setEnabled(false);
            BStudName.setBorder(borderBlack);
            BStudName.setBackground(Color.DARK_GRAY);

            BStart.setEnabled(false);
            BStart.setBorder(borderBlack);
            BStart.setBackground(Color.DARK_GRAY);
        }
    }

    // FRAME
    private  JFrame CreateFrame(int width, int height) {
        JFrame MainFrame = new JFrame("SATORRE-ACT8Lab");
        MainFrame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        MainFrame.setResizable(false);
        MainFrame.setBounds(10,10, width, height);
        MainFrame.setLayout(null);
        MainFrame.setLocationRelativeTo(null);

        return MainFrame;
    }

    // PANEL
    private JPanel CreatePanel(Border border,Color color, int x, int y, int width, int height){
        JPanel Create = new JPanel();
        Create.setBackground(color);
        Create.setBorder(border);
        Create.setLayout(null);
        Create.setBounds(x, y, width, height);

        return Create;
    }

    // LABEL
    private JLabel CreateLabel(String type, Color color, boolean visible, int x ,int y, int width, int height){
        JLabel CreateL = new JLabel(type);
        CreateL.setForeground(color);
        CreateL.setVisible(visible);
        CreateL.setBounds(x, y,width,height);

        return CreateL;
    }

    // BUTTON
    private JButton CreateButton(String type,int FontSize, Border border,Color color, int x, int y, int width, int height) {
        JButton Create = new JButton(type);
        Create.setFont(new Font("Arial", Font.BOLD, FontSize));
        Create.setBackground(color);
        Create.setForeground(Color.BLACK);
        Create.setCursor(new Cursor(Cursor.HAND_CURSOR));
        Create.setBorder(border);
        Create.addActionListener(this);
        Create.setFocusable(false);
        Create.setBounds(x, y, width,height);

        return Create;
    }

    // ADD COMPONENTS for 1st Page
    private void AddComponentsFor1stPage() {
        // ADD to Panel Design Color red on the Right Side
        PDredRight.add(PDcRedRight);
        PDredLeft.add(PDcRedLeft);

        // ADD to Heading Title for name and ACTIVITY 7
        pHeading.add(LTitleName);
        pHeading.add(LTitle);

        // ADD to pDisplayOnOff
        pDisplayOnOff.add(LOff);
        pDisplayOnOff.add(LOn);

        // ADD to pOnOff
        pOnOff.add(pDisplayOnOff);
        pOnOff.add(LPower);

        // ADD to Panel Center
        pCenter.add(BStudName);
        pCenter.add(BStart);
        pCenter.add(PDcBlue);
        pCenter.add(PDcGreen);
        pCenter.add(PDcRED);
        pCenter.add(PDcBlack);

        // ADD to Frame
        f.add(BOff);
        f.add(BOn);
        f.add(BExit);
        f.add(PDredRight);
        f.add(PDredLeft);
        f.add(pOnOff);
        f.add(pCenter);
        f.add(pHeading);
        f.add(pBackBorder);

    }

    // ADD COMPONENTS for Loading Frame
    private void AddComponentsForLoadingFrame() {
        // Add to Heading
        pHeading.add(LWaiting);
        pHeading.add(LTitle);

        // Add to Loading Background
        PBackground.add(LPercent);
        PBackground.add(PGreen);

        // Frame Loading
        FLoading.add(BProceed);
        FLoading.add(pHeading);
        FLoading.add(PBackground);
    }

    // MY NAME
    private void showStudentName() {
        LTitle.setVisible(false);
        LTitleName.setVisible(true);
        JOptionPane.showMessageDialog(null, "LANCE TIMOTHY B. SATORRE");
        LTitleName.setVisible(false);
        LTitle.setVisible(true);
    }

    // LOADING DESIGN..
    private void Loading() {
        Timer timer = new Timer(220, e -> {
            if (loadings <= 101) {
                LPercent.setText(String.format("LOADING: %d%%", loadings));
                loadings += 10;

            if (greenLoading <= 401) {
                PGreen.setBounds(4, 4, greenLoading, 50);
                greenLoading += 39; }
            } else {
                ((Timer) e.getSource()).stop();
                LTitle.setVisible(true);
                LWaiting.setVisible(false);
                BProceed.setEnabled(true);
                BProceed.setBackground(Color.YELLOW);
            }
        });
        timer.start(); // START LOADING
    }
}