package Act8Satorre;

import javax.swing.*;

public class InsuredCarDemo{
    public static void main(String[] args) {
       new STARTgui();
    }

    public void MainAct8() {
        do {
            InsuredCar myCar = new InsuredCar();
            JOptionPane.showMessageDialog(null,myCar.toString());
            int response = JOptionPane.showConfirmDialog(
                    null,
                    "Do you want to try again?",
                    "",
                    JOptionPane.YES_NO_OPTION);

            if (response == JOptionPane.NO_OPTION) {
                break;
            } else {
                System.out.println("\n+=-----------------------------------=+");
                System.out.println(" --> NEW ATTEMPT \n");
            }
        }while(true);
        System.out.println("\n\n --> EXIT PROGRAM...");
    }

}
