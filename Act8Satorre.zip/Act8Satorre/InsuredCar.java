package Act8Satorre;

import javax.swing.*;
public class InsuredCar extends Vehicle implements Insured{
    // Properties
    private int coverage;

    // Constructor
    public InsuredCar() {
        super("gas",4);
        setCoverage();
    }

    // METHOD 1: set price for Car
    public void setPrice(){
        String entry;

        final int MAX = 60000; // Max price
        boolean check = true; // enter while loop
        while (check) {
            try {
                entry = JOptionPane.showInputDialog(null, "Enter car price ");
                if( entry == null) {
                    System.out.println("\n --> EXIT PROGRAM... ");
                    System.exit(0);
                    break;
                }
                price = Integer.parseInt(entry);
                if(price < 20000 || price > 60000) {
                    JOptionPane.showMessageDialog(null,
                            "Price is out of Range!\n Min: $20,000\n Max: $60,000 "); // this is for minimum price
                } else {
                    System.out.printf(" --> CAR PRICE: $%,d\n", price);
                    check = false; // exit while loop
                }
            } catch (NumberFormatException  e) {
                JOptionPane.showMessageDialog(null, "  INVALID INPUT! ");
            }
        }
        if(price > MAX)
            price = MAX;
    }

    // METHOD 2: set Coverage for Car
    public void setCoverage(){
        coverage = (int) (price * 0.9);
    }

    // METHOD 3: get Coverage for Car
    public int getCoverage() {
        return coverage;
    }

    // METHOD 4: Display info, toString
    public String toString(){
        return String.format("- The insured car is powered by %s; it has %d wheels, costs $%,d and is insured for $%,d",
                             getPowerSource(), getWheels(), getPrice(), getCoverage());
    }
}

