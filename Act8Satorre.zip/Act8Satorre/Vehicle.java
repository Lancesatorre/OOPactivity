package Act8Satorre;

public abstract  class Vehicle {
    // Properties
    private String powerSource;
    private int wheels;
    protected int price;

    // public abstract void display();
    public Vehicle(String powerSource, int wheels){
        setPowerSource(powerSource);
        setWheels(wheels);
        setPrice();
    }

    // METHOD 1: Get the Power Source
    public String getPowerSource(){
        return powerSource;
    }

    // METHOD 2: Set the Power Source
    public void setPowerSource(String powerSource){
        this.powerSource = powerSource;
    }

    // METHOD 3: Get Wheels
    public int getWheels(){
        return wheels;
    }

    // METHOD 4: Set Wheels
    public void setWheels(int wheels){
        this.wheels = wheels;
    }

    // METHOD 5: Get the price
    public int getPrice(){
        return price;
    }

    // METHOD 5: Set the price
    public abstract void setPrice();
}
