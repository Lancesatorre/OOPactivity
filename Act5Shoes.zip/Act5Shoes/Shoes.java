package Act5Shoes;

import java.util.Random;
import java.util.Scanner;
public class Shoes {
        Random rand = new Random();
        Scanner in = new Scanner(System.in);

        // PROPERTIES
        private final String[] Brand = {"NIKE", "ADIDAS", "LACOSTE"};
        private final String[] TypeOfShoes = {"SPORT", "AESTHETIC","STYLISH", "WORK"};
        private final String[] Dsign = {"MINIMAL", "CARTOON", "PLAIN", "ANIME", "GALAXY", "DOTS"};
        private final String[] Color = {"BLACK", "BLUE", "GREEN", "KHAKI", "BROWN", "RED"};
        int[] Size;
        private int[] Price;
        int choose;
        int choice = 0;

        // CONSTRUCTOR 1
        public Shoes() {
        }

        // CONSTRUCTOR 2
        public Shoes(int choose, int[] size, int[] price) {
                this.choose = choose;
                this.Size = size;
                this.Price = price;
        }

        // METHOD 1: DISPLAY BRAND OF SHOES
        void displayBrandShoes() {
                    System.out.print("|==================================| BRAND |===================================|\n\n");
                System.out.printf("                         |======--|| %s ||--======|\n",Brand[choose - 1]);
            }
        // METHOD 2: MENU FOR TYPE OF SHOES
        int MenuOfType() {
        int choice = 0;
        System.out.print(" MENU: \n");
        for (int i = 0; i < TypeOfShoes.length; i++) {
            System.out.printf(" %d. %s\n", i + 1, TypeOfShoes[i]);
        }
        while (choice == 0) {
            System.out.print(" Choose type of Shoe: ");
            if (in.hasNextInt()) {
                choice = in.nextInt();
                if (choice < 1 || choice > 4) {
                    System.out.println("=== THE NUMBER YOU ENTERED IS NOT ON THE MENU! -----");
                    choice = 0;
                }
            } else {
                System.out.println("=== INVALID INPUT. PLEASE ENTER AN INTEGER. -----");
                in.next();
            }
        }
        return choice;
    }

        // METHOD 3: FOR BUYING SHOES
        void BuyShoe() {
            int choose = MenuOfType();
            switch ( choose) {
                case 1 :
                    System.out.print("\n       |-=========================| SPORT SHOE |========================-|\n");
                    displayAvailableShoe();
                    break;
                case 2 :
                    System.out.print("\n       |-=======================| AESTHETIC SHOE |======================-|\n");
                    displayAvailableShoe();
                    break;
                case 3 :
                    System.out.print("\n       |-========================| STYLISH SHOE |=======================-|\n");
                    displayAvailableShoe();
                    break;
                case 4:
                    System.out.print("\n       |-=========================| WORK SHOE |=========================-|\n");
                    displayAvailableShoe();
                    break;
            }
        }

        // METHOD 4: DISPLAY THE AVAILABLE SHOES
        void displayAvailableShoe() {
            int[] randDesign = new int[Dsign.length];
            int[] randColor = new int[Dsign.length];

            for(int i = 0; i < Size.length; i++)
                randDesign[i] = rand.nextInt(Dsign.length); // GENERATE RANDOM INDEX of Design
            for(int i = 0; i < Size.length; i++) {
                randColor[i] = rand.nextInt(Dsign.length); // GENERATE RANDOM INDEX of Color
                System.out.print("                      |=====================================|\n");
                System.out.printf("                      |             SHOES NO.%d              |\n", i+1);
                System.out.printf("                      | DESIGN: %-3s     COLOR: %s   \n", Dsign[randDesign[i]],Color[randColor[i]]);
                System.out.printf("                      | SIZE: %-5d PRICE: P%d.00          |\n", Size[i], Price[i]);
                System.out.print("                      |-------------------------------------|\n\n");
            }

            while (choice == 0) {
                System.out.print("(BUY ITEM) Choose Shoes No.: ");
                if (in.hasNextInt()) {
                    choice = in.nextInt();
                    if (choice < 1 || choice > Size.length) {
                        System.out.println("=== THE NUMBER YOU ENTERED IS NOT ON THE STORAGE! -----");
                        choice = 0;
                    } else {
                        // DISPLAY THE PURCHASE ITEM
                        System.out.print("\n                               -= PURCHASE ITEM =-\n");
                        System.out.print("                      |=====================================|\n");
                        System.out.printf("                      |             SHOES NO.%d              |\n", choice);
                        System.out.printf("                      | DESIGN: %-3s     COLOR: %s   \n", Dsign[randDesign[choice - 1]],
                                                                                                    Color[randColor[choice - 1]]);
                        System.out.printf("                      | SIZE: %-5d PRICE: P%d.00          |\n", Size[choice - 1], Price[choice - 1]);
                        System.out.print("                      |-------------------------------------|\n\n");
                    }
                } else {
                    System.out.println("=== INVALID INPUT. PLEASE ENTER AN INTEGER. -----");
                    in.next();
                }
            }
        }

        // METHOD 5: PAYMENT
        void PayAndChange() {
            int money;
            int change;
            while (true) {
                System.out.print("Input Money: ");
                if (in.hasNextInt()) {
                    money = in.nextInt();
                    if (money < Price[ choice - 1 ]) {
                        System.out.println("===| YOUR MONEY IS NOT ENOUGH |===");
                    }
                    else {
                        change = money - Price[ choice - 1];
                        break;
                    }
                } else {
                    System.out.println("=== INVALID INPUT. PLEASE ENTER AN INTEGER. -----");
                    in.next();
                }
            }
            System.out.printf("\n                              ________________________\n" +
                              "                              | MONEY: P%d.00       |\n" +
                              "                              | PRICE: - P%d.00     |\n"+
                              "                              | -------------------- |\n"+
                              "                              | CHANGE: P%d.00       |\n"+
                              "                              ------------------------\n",money,Price[choice - 1],change);

            System.out.print("\n                    -==| THANK YOU FOR BUYING TO MY STORE |==-\n");
        }



}

