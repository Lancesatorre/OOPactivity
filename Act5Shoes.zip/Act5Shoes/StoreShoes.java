package Act5Shoes;

import java.util.Random;
import java.util.Scanner;

// MAIN
    class StoreShoes {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("\n                  ===| SATORRE - Midterm - Lab.Act.#05 |===\n"); // TITLE
        int attempt = 1;
        String answer;

        do {
            System.out.printf("\n|=========================| START OF ATTEMPT NO.%d |===========================|\n", attempt);
            int[] sizes = GenerateValue(true);
            int[] prices = GenerateValue(false);

            int choose = Menu(in);
            switch (choose) {
                case 1:
                    Shoes NIKE = new Shoes(choose,sizes,prices); // OBJECT 1
                    // CALLING METHODS
                    NIKE.displayBrandShoes();
                    NIKE.BuyShoe();
                    NIKE.PayAndChange();
                    break;
                case 2:
                    Shoes ADIDAS = new Shoes(choose,sizes,prices); // OBJECT 2
                    // CALLING METHODS
                    ADIDAS.displayBrandShoes();
                    ADIDAS.BuyShoe();
                    ADIDAS.PayAndChange();
                    break;
                case 3:
                    Shoes LACOSTE = new Shoes(choose,sizes,prices); // OBJECT 3
                    // CALLING METHODS
                    LACOSTE.displayBrandShoes();
                    LACOSTE.BuyShoe();
                    LACOSTE.PayAndChange();
                    break;
            }
            System.out.printf("\n|=========================| END OF ATTEMPT NO.%d |===========================|\n", attempt);
            in.nextLine();
            answer = getAnswerLoop(in);
            System.out.print("|===================================================================================|\n\n");
            attempt++;
        } while (answer.equalsIgnoreCase("yes"));

        System.out.print("                           THANK YOU FOR YOUR TIME\n");
        System.out.printf("                             NO. OF ATTEMPTS: %d", attempt - 1);
        in.close();
    }

    // MENU FOR CHOOSING BRAND
    public static int Menu(Scanner in) {
        String[] menu = {"NIKE", "ADIDAS", "LACOSTE"};
        int choice = 0;
        System.out.print(" MENU: \n");
            for (int i = 0; i < menu.length; i++) {
                System.out.printf(" %d. %s\n", i + 1, menu[i]);
            }
                while (choice == 0) {
                    System.out.print(" Choose Brand: ");
                    if (in.hasNextInt()) {
                        choice = in.nextInt();
                        if (choice < 1 || choice > 3) {
                            System.out.println("=== THE NUMBER YOU ENTERED IS NOT ON THE MENU! -----");
                            choice = 0;
                        }
                    } else {
                        System.out.println("=== INVALID INPUT. PLEASE ENTER AN INTEGER. -----");
                        in.next();
                    }
                }
        return choice;
     }

    // GENERATE NUMBER OF SIZE AND VALUE OF PRICE
    public static int[] GenerateValue(boolean check) {
         Random rand = new Random();
         int[] value = new int[5];
         for(int i=0; i < value.length; i++) {
             if (check) {
                 value[i] = rand.nextInt(11) + 35;
             }
             else {
                 value[i] = 295 + (rand.nextInt((1000 - 300) / 5 + 1) * 5);
             }
         }
         return value;
     }

    // LOOPING METHOD
    public static String getAnswerLoop(Scanner in) {
        String answer;
        while (true) {
            System.out.print("DO YOU WANT TO TRY AGAIN? (YES/NO): ");
            answer = in.nextLine().trim();
            if (answer.equalsIgnoreCase("yes") || answer.equalsIgnoreCase("no")) {
                break;
            } else if (answer.isEmpty()) {
                System.out.println("|-= INVALID INPUT, YOU DIDN'T INPUT ANYTHING =-|");
            }else {
                System.out.println("======--- INVALID INPUT! -----");
            }
        }
        return answer;
    }
}

