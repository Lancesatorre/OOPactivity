package SatorreACT6;

import java.util.Random;
import java.util.Scanner;

public class Car extends Vehicle {
        // Properties
        private int[] noOfDoors;
        private int[] RandomInCar;

        // Constructor 1
        public Car() {
        }

        // Constructor 2
        public Car(String[] name, int[] maxSpeed, int choice, int[] Price, int[] noOfDoors ) {
                super(name, maxSpeed, choice, Price);
                this.noOfDoors = noOfDoors;
                this.RandomInCar = new int[name.length];
        }

        // Method 1: Get info the Car and Pass it to DisplayInfo
        private void GetCarInfo(int index, boolean CheckCarType) {
                String type = CheckCarType ? "SPORT CAR" : "NORMAL CAR"; // TYPE OF CAR
                System.out.println("\n               |+=--------------------------------------=+|");
                System.out.printf("                            %s No.%d\n\n" +
                                  "                      CAR NAME: %s\n" +
                                  "                     MAX SPEED: %d km/h\n" +
                                  "                         DOORS: %d\n\n" +
                                  "                        PRICE: P %,d.00\n", type, index + 1, name[RandomInCar[index]],
                                                                                                maxSpeed[RandomInCar[index]],
                                                                                                noOfDoors[RandomInCar[index]],
                                                                                                Price[RandomInCar[index]]);
                System.out.println("               |+=--------------------------------------=+|");

                }

        @Override // Method 2: Override displayInfo
        public void displayInfo(boolean check) {
                Random rand = new Random();
                RandomInCar = new int[LengthOfForSale];

                for (int i = 0; i < RandomInCar.length; i++) {
                        int newIndex;

                        while (true) {
                                newIndex = rand.nextInt(name.length);
                                boolean isDuplicate = false;
                                for (int j = 0; j < i; j++) {
                                        if (RandomInCar[j] == newIndex) {
                                                isDuplicate = true;
                                                break;
                                        }
                                }
                                if (!isDuplicate) {
                                        RandomInCar[i] = newIndex;
                                        break;
                                }
                        }
                        GetCarInfo(i, check);
                }
                System.out.printf("\n                       -=| ONLY %d CAR AVAILABLE |=-\n",LengthOfForSale);
        }

        @Override  // Method 3: Override the Vehicle Type Buying
        public void VehicleTypeBuy(Scanner in, String buy, boolean checkTypeCar) {
                System.out.print("\n     |+==-------------------------------------------------------==+|");
                while (buy.equalsIgnoreCase("YES")) {
                        System.out.print("\n     ---> (BUY CAR) Choose Car No.: ");
                        if (in.hasNextInt()) {
                                int pick = in.nextInt() - 1;
                                if (pick < 0 || pick >= LengthOfForSale) {
                                        System.out.println("         === THE NUMBER YOU ENTERED IS NOT IN THE STORAGE! -----");

                                } else {
                                        choice = pick;
                                        GetCarInfo(pick, checkTypeCar);
                                        break;
                                }
                        } else {
                                System.out.println("            === INVALID INPUT. PLEASE ENTER AN INTEGER. -----");
                                in.next();
                        }
                }
                HandlePaymentForCar(in, RandomInCar);
        }

        // Method 4: Payment Method
        private void HandlePaymentForCar(Scanner in, int[] randIndex) {
                int money;
                int change;
                System.out.print("\n\n      |+==-------------------| PAYMENT METHOD |------------------==+|");

                while (true) {
                        System.out.print("\n       ---> Input Money: ");
                        if (in.hasNextInt()) {
                                money = in.nextInt();
                                if (money < Price[randIndex[choice]]) {
                                        System.out.println("                    ===| YOUR MONEY IS NOT ENOUGH |===");
                                } else {
                                        change = money - Price[randIndex[choice]];
                                        break;
                                }
                        } else { System.out.println("             === INVALID INPUT. PLEASE ENTER AN INTEGER. -----");
                                 in.next();
                        }
                }

                System.out.printf("\n                      _______________________________\n" +
                                        "                         MONEY: P%,d.00       \n" +
                                        "                         PRICE: - P%,d.00     \n" +
                                        "                         -------------------- \n" +
                                        "                         CHANGE: P%,d.00       \n" +
                                        "                      -------------------------------\n", money, Price[randIndex[choice]], change);
                System.out.print("\n      |+==-------------------------------------------------------==+|");
                System.out.print("\n                 -==| THANK YOU FOR BUYING AT MY STORE |==-\n");
        }
}
