package SatorreACT6;

import java.util.Random;
import java.util.Scanner;

public class Vehicle  {
    Random rand = new Random();

    // Properties
    String[] name;
    int[] maxSpeed;
    int[] Price;
    int choice;
    int LengthOfForSale;


    //CONSTRUCTOR 1
    public Vehicle() {
    }

    //CONSTRUCTOR 2
    public Vehicle(String[] name, int[] maxSpeed, int Choice, int[] Price) {
        this.name = name;
        this.maxSpeed = maxSpeed;
        this.choice = Choice;
        this.Price = Price;
        this.LengthOfForSale  = rand.nextInt(5) + 3; // RANDOM 7 MAXIMUM
    }

    // METHOD 1: DISPLAY INFO
    public void displayInfo(boolean check) {
        Random rand = new Random();
        String[] NoOfItem = new String[LengthOfForSale];

        for (int i = 0; i < NoOfItem.length; i++) {
            int randIndex = rand.nextInt(name.length);
                System.out.println("\n|+=--------------------------------------=+|");
                System.out.printf(" NAME: %s\n MAX SPEED: %d km/h\n",name[randIndex],maxSpeed[randIndex]);
                System.out.println("|+=--------------------------------------=+|");
        }
    }

    // METHOD 2: IF YOU BUY OR NOT
    public String BuyOrNot(Scanner in, String TypeVehicle) {
        String answer;
        while (true) {
            System.out.printf("\n          ---> ((YES) BUY %s /(NO) BACK): ", TypeVehicle);
            answer = in.nextLine().trim();
            if (answer.equalsIgnoreCase("yes") || answer.equalsIgnoreCase("no")) {
                break;
            } else if (answer.isEmpty()) {
                System.out.println("           |-= INVALID INPUT, YOU DIDN'T INPUT ANYTHING =-|");
            }else {
                System.out.println("                   ======--- INVALID INPUT! -----");
            }
        }
        return answer;
    }

    // METHOD 3: BUYING VEHICLE

    public void VehicleTypeBuy(Scanner in, String Buy, boolean check) {
        // THIS IS EMPTY, I USE IT TO DISPLAY THE VEHICLE FOR SALE...
        // SO THAT I CAN USE THE METHOD TO THE SUB CLASS
    }
}

