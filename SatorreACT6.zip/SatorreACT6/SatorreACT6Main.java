/*******************************************************************************************
 *  NAME: SATORRE , LANCE TIMOTHY B.
 *  SECTION: BSIT 2B
 *  SCHEDULE: MTWTH
 *****************************************************************************************/
package SatorreACT6;

import java.util.Random;
import java.util.Scanner;

// MAIN
class SatorreACT6Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("\n                  ===| SATORRE - Midterm - Lab.Act.#06 |===\n"); // TITLE
        int attempt = 1;
        String answer;

        do {
            System.out.printf("\n                    --+===| START OF ATTEMPT NO.%d |===+--\n", attempt);
            boolean back = true;
            do {
                System.out.println("\n|+===========================================================================+|");
                int choice = MenuOfVehicleType(in,"Vehicle", "VEHICLE TYPE");
                switch (choice) {
                    case 1: int selectCar = CarChoice(in);
                        if (selectCar == 1 || selectCar == 2) {
                            back = false;
                        }
                        break;
                    case 2: int selectBicycle = BicycleChoice(in);
                        if (selectBicycle == 1 || selectBicycle == 2) {
                            back = false;
                        }
                        break;
                    case 3: int selectBus = BusesChoice(in);
                        if (selectBus == 1 || selectBus == 2) {
                            back = false;
                        }
                        break;
                    default:
                        break;
                }

            }while(back);
            System.out.printf("\n|=========================| END OF ATTEMPT NO.%d |===========================|\n", attempt);
            in.nextLine();
            answer = getAnswerLoop(in);
            System.out.print("|===================================================================================|\n\n");
            attempt++;
        } while (answer.equalsIgnoreCase("yes"));

        System.out.print("                           THANK YOU FOR YOUR TIME\n");
        System.out.printf("                             NO. OF ATTEMPTS: %d", attempt - 1);
        in.close();
    }

    // MENU FOR TYPE OF VEHICLE AND ITS OWN TYPE
    public static int MenuOfVehicleType(Scanner in, String check, String title) {
        String[] menu;
        switch(check.toLowerCase()) {
            case "vehicle": menu = new String[]{"CAR", "BICYCLE", "BUS"}; break; // FOR MENU OF VEHICLE
            case "car": menu = new String[]{"SPORT CAR", "NORMAL CAR", "BACK"}; break; // MENU OF TYPE CAR
            case "bicycle": menu = new String[]{"NORMAL BICYCLE", "ELECTRIC BICYCLE", "BACK"}; break; // MENU OF TYPE BICYCLE
            case "bus": menu = new String[]{"HIGH-TECH BUS", "NORMAL BUS", "BACK"}; break; // MENU OF TYPE OF BUS
            default: menu = new String[]{""}; break;
        }

        int choice = 0;
        System.out.print("\n         |+++=---------------------------------------------------=+++|\n");
        System.out.printf("                             -==| %s |==-\n", title);
        System.out.print("         MENU \n");
        for (int i = 0; i < menu.length; i++) {
            System.out.printf("          %d. %s\n", i + 1, menu[i]);
        }
        while (choice == 0) {
            System.out.printf("        ---> Choose %s: ", title);
            if (in.hasNextInt()) {
                choice = in.nextInt();
                if (choice < 1 || choice > 3) {
                    System.out.println("               === THE NUMBER YOU ENTERED IS NOT ON THE MENU! -----");
                    choice = 0;
                }
            } else {
                System.out.println("                === INVALID INPUT. PLEASE ENTER AN INTEGER. -----");
                in.next();
            }
        }

        System.out.println("         |+++=---------------------------------------------------=+++|");
        return choice;
    }

    /////////////////////////////////////////////////////////////////////////////////////////// - CARS
    // IF USER CHOOSE CAR
    static int CarChoice(Scanner in) {
        int choose;
        while (true) {
            choose = MenuOfVehicleType(in, "Car", "CAR TYPE");
            in.nextLine();
            if (choose == 3) break; // EXIT IF USER CHOOSE 3

            boolean Checking = (choose == 1); // IF TRUE DISPLAY THE NUM.1 BUT IF FALSE NUM.2

            // OBJECT 1 - CAR
            Vehicle TypeCar = new Car(CarAvailableArray(Checking), KMH("Car", Checking),
                    choose, GeneratePrice(choose, "Car"), noOfDoorsCAR(Checking)
            );

            TypeCar.displayInfo(Checking); // DISPLAY THE FOR SALE VEHICLE OR THE INFO
            if (TypeCar.BuyOrNot(in, "CAR").equalsIgnoreCase("YES")) {
                TypeCar.VehicleTypeBuy(in, "YES", Checking);
                break;
            }
        }
        return choose;
    }

    // ARRAY OF FOR SALE CAR
    static String[] CarAvailableArray(boolean check) {
        String[] sportCars = { "FORD MUSTANG", "LAMBORGHINI", "JAGUAR F-TYPE", "PORSCHE 718", "BMW M3",
                "CHEVROLET CAMARO", "BMW 8 SERIES", "TOYOTA GR876", "PORSCHE 911", "BUGATTI"};

        String[] normalCars = { "MARK X", "FJ CRUISER", "PORTE", "ESTIMA", "ARION",
                "ISIS", "RUSH", "COUPE", "VANGUARD","SEDAN"};

        return check ? sportCars : normalCars;
    }

    // GET NO OF DOORS
    static int[] noOfDoorsCAR(boolean check) {
        int[] sportCars = {2, 2, 2, 2, 4,
                2, 2, 2, 2, 2 };
        int[] normalCars = {4, 2, 2, 4, 4,
                4, 4, 2, 4, 2};

        return check ? sportCars : normalCars;
    }

    /////////////////////////////////////////////////////////////////////////////////////////// - BICYCLES
    // IF USER CHOOSE BICYCLE
    static int BicycleChoice(Scanner in) {
        int choose;
        while (true) {
            choose = MenuOfVehicleType(in, "Bicycle", "BICYCLE TYPE");
            in.nextLine();
            if (choose == 3) break; // EXIT IF USER CHOOSE 3

            boolean Checking = (choose == 1);  // IF TRUE DISPLAY THE NUM.1 BUT IF FALSE NUM.2

            // OBJECT 2 - BICYCLE
            Vehicle TypeBycicle = new Bicycle( BicycleAvailableArray(Checking), KMH("Bicycle", Checking),
                    choose, GeneratePrice(choose, "Bicycle") );

            TypeBycicle.displayInfo(Checking); // DISPLAY THE FOR SALE VEHICLE OR THE INFO
            if (TypeBycicle.BuyOrNot(in, "BICYCLE").equalsIgnoreCase("YES")) {
                TypeBycicle.VehicleTypeBuy(in, "YES", Checking);
                break;
            }
        }
        return choose;
    }

    // ARRAY OF FOR SALE BICYCLE
    static String[] BicycleAvailableArray(boolean check) {

        String[] NormalBike = { "CRUISER", "MOUNTAIN MONARCH  ", "URBAN EXPLORER", "SPEEDSTER", "TRAILBLAZER",
                "ADVENTURE SEEKER", "COMMUTER CLASSIC", "ROAD WARRIOR", "ECO RIDER", "RETRO REVIVAL"};

        String[] ElectricBike = { "RAD POWER RADROVER", "TREK VERVE+  ", "TURBO VADO",
                "CANNONDALE NEO", "ELEC TOWNIE GO!", "BIANCHI E-OMNIA", "GIANT EXPLORE E+",
                "ANCHEER MOUNTAIN BIKE", "RIESE & MÜLLER SUPERDELITE", "JUICED CROSSCURRENT"};

        return check ? NormalBike : ElectricBike;
    }

    /////////////////////////////////////////////////////////////////////////////////////////// - BUSES
    // IF USER CHOOSE BUS
    static int BusesChoice(Scanner in) {
        int choose;
        while (true) {
            choose = MenuOfVehicleType(in, "Bus", "BUS TYPE");
            in.nextLine();
            if (choose == 3) break; // EXIT IF USER CHOOSE 3

            boolean Checking = (choose == 1); // IF TRUE DISPLAY THE NUM.1 BUT IF FALSE NUM.2

            // OBJECT 3 - BUS
            Vehicle TypeBus = new Bus( BusAvailableArray(Checking), KMH("Bus", Checking),
                    choose, GeneratePrice(choose, "Bus"), GeneratePassenger());

            TypeBus.displayInfo(Checking);  // DISPLAY THE FOR SALE VEHICLE OR THE INFO
            if (TypeBus.BuyOrNot(in,"BUS").equalsIgnoreCase("YES")) {
                TypeBus.VehicleTypeBuy(in, "YES", Checking);
                break;
            }
        }
        return choose;
    }

    // ARRAY OF FOR SALE BUS
    public static String[] BusAvailableArray(boolean check) {

        String[] HighTechBus = {"FUTURE FLEET", "SMART SHUTTLE", "TECH TRANSIT", "INNOVATION EXPRESS", "ELECTRO BUS",
                "CONNECTED COMMUTER", "AUTONOMOUS ADVENTURER", "DIGITAL DRIFTER", "INTELLIGENT INTERCITY", "VIRTUAL VOYAGER"
        };

        String[] NormalBus = { "THE ROLLING ROAMER", "MOUNTAIN URBAN VOYAGER", "URBAN EXPLORER", "SPEEDSTER", "TRAILBLAZER",
                "ADVENTURE SEEKER", "ROAD WARRIOR", "ECO RIDER", "CITY CRUISER", "JOURNEY JAMBOREE"
        };

        return check ? HighTechBus : NormalBus;
    }

    // GENERATE PASSENGER OF ALL TYPE OF BUS
    public static int[] GeneratePassenger() {

        Random rand = new Random();
        int[] Passenger = new int[10];

        for (int i = 0; i < Passenger.length; i++) {
            Passenger[i] = rand.nextInt(31) + 40;
        }

        return Passenger;
    }

    /////////////////////////////////////////////////////////////////////////////////// - FOR ALL VEHICLE
    // GET KM/H OF ALL TYPE OF VEHICLE
    static int[] KMH(String choiceKMH, boolean Check) {
        Random rand = new Random();
        int[] KMH = new int[10];
        int min, max;

        // KMH FOR CAR
        if (choiceKMH.equalsIgnoreCase("Car")) {
            min = Check ? 300 : 100;
            max = Check ? 400 : 250;
        }
        // KMH FOR BICYCLE
        else if (choiceKMH.equalsIgnoreCase("Bicycle")) {
            min = Check ? 16 : 28;
            max = Check ? 50 : 71;
        }
        // KMH FOR BUS
        else {
            min = Check ? 31 : 21;
            max = Check ? 90 : 80;
        }

        for (int i = 0; i < KMH.length; i++) {
            KMH[i] = rand.nextInt(max - min) + min;
        }
        return KMH;
    }

    // GENERATE PRICE OF ALL TYPE OF VEHICLE
    public static int[] GeneratePrice(int check, String CheckType) {

        Random rand = new Random();
        int[] value = new int[10];

        for (int i = 0; i < value.length; i++) {
            int multiplier; // MULTIPLAYER TO GET THE EXACT VALUE
            int basePrice; // BASE PRICE

            // CAR
            if (CheckType.equalsIgnoreCase("Car")) {
                basePrice = (check == 1) ? rand.nextInt(250) + 50 : rand.nextInt(71) + 30;
                multiplier = 1000000;
            }
            // BICYCLE
            else if (CheckType.equalsIgnoreCase("Bicycle")) {
                basePrice = (check == 1) ? rand.nextInt(71) + 30 : rand.nextInt(101) + 100;
                multiplier = 1000;
            }
            // BUS
            else {
                basePrice = (check == 1) ? rand.nextInt(101) + 100 : rand.nextInt(71) + 30;
                multiplier = 10000;
            }
            value[i] = basePrice * multiplier;
        }
        return value;
    }

    // FOR LOOPING
    public static String getAnswerLoop(Scanner in) {
        String answer;
        while (true) {
            System.out.print(" ---> DO YOU WANT TO TRY AGAIN? (YES/NO): ");
            answer = in.nextLine().trim();
            if (answer.equalsIgnoreCase("yes") || answer.equalsIgnoreCase("no")) {
                break;
            } else if (answer.isEmpty()) {
                System.out.println("           |-= INVALID INPUT, YOU DIDN'T INPUT ANYTHING =-|");
            }else {
                System.out.println("                     ======--- INVALID INPUT! -----");
            }
        }
        return answer;
    }
}
