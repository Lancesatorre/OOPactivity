package Act7Satorre;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GUIFrame implements ActionListener {
    // Properties
    boolean check = false;
    //================================================= NORMAL USED
    JFrame f;
    JPanel pBackBorder, pUpper, pCenter, pOnOff, pDisplayOnOff;
    JLabel LPower, LOn, LOff, LTitle, LTitleName;
    JButton BStart, BOn,BOff, BStudName, BExit;
    Border borderBlack,borderRed, borderGray, borderDarkGray;

    //================================================= FOR DESIGN
    JPanel PDredLeft, PDredRight, PDcBlack, PDcBlue, PDcGreen, PDcRED, PDcRedLeft, PDcRedRight;

    // CONSTRUCTOR
    public GUIFrame() {
        //========================================================================= BORDER
        borderBlack = BorderFactory.createLineBorder(Color.black, 5);
        borderRed = BorderFactory.createLineBorder(Color.red, 3);
        borderGray = BorderFactory.createLineBorder(Color.gray, 4);
        borderDarkGray = BorderFactory.createLineBorder(Color.gray, 6);

        //========================================================================= FRAME
        f = CreateFrame();
        //========================================================================= PANEL
        pBackBorder = CreatePanel(borderDarkGray,null,0,0,385,593);
        pUpper = CreatePanel(borderRed,Color.black ,25,20,335,70);
        pCenter = CreatePanel(borderBlack, Color.gray,25,150,335,300);
        pOnOff = CreatePanel(null,null ,25,115,150,30);
        pDisplayOnOff = CreatePanel(borderGray,Color.black ,60,2,50,26);

        //========================================================================= LABEL
        LTitleName = CreateLabel("STUDENT NAME", Color.GREEN,false, 30,6,300,60);
        LTitleName.setFont(new Font("Arial", Font.BOLD, 35));
        LTitle =  CreateLabel("ACTIVITY 7", Color.GREEN,false, 60,6,300,60);
        LTitle.setFont(new Font("Arial", Font.BOLD, 40));
        LOn = CreateLabel("ON", Color.GREEN,false, 15, 0 ,60,26);
        LOff = CreateLabel("OFF", Color.RED,true, 15, 0 ,60,26);
        LPower = CreateLabel("POWER: ", null, true,0, 0 ,80,35);
        LPower.setFont(new Font("Arial", Font.BOLD, 13));

        //========================================================================= BUTTON
        BExit = CreateButton("EXIT",15,borderBlack,Color.ORANGE,152,530,80,30);
        BStudName = CreateButton("STUDENT NAME",15,borderBlack,Color.darkGray,85,200,160,60);
        BStudName.setEnabled(false);
        BStart = CreateButton("START",40,borderBlack,Color.darkGray,40,80,250,100);
        BStart.setEnabled(false);
        BOn = CreateButton("ON",15,borderBlack,Color.GREEN,125,470,60,35);
        BOff = CreateButton("OFF",15,borderBlack,Color.RED,200,470,60,35);

        //========================================================================= DESIGN PANEL
        PDcBlack = CreatePanel(borderBlack, Color.BLACK ,75,0,60,100);
        PDcGreen = CreatePanel(borderBlack, Color.GREEN ,143,0,20,250);
        PDcRED = CreatePanel(borderBlack, Color.RED ,170,0,20,250);
        PDcBlue = CreatePanel(borderBlack, Color.BLUE ,197,0,60,100);

        PDcRedLeft = CreatePanel(borderBlack, Color.DARK_GRAY ,24,10,20,100);
        PDredLeft = CreatePanel(borderBlack, Color.RED ,40,445,70,150);

        PDcRedRight = CreatePanel(borderBlack, Color.DARK_GRAY ,24,10,20,100);
        PDredRight = CreatePanel(borderBlack, Color.RED,275,445,70,150);

        //========================================================================= DISPLAY AND ADD
        AddNeedComponents();

        f.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource() == BOn) {
            check = true;
            updateLabelsAndButton(true);
        }

        if(e.getSource() == BOff){
            check = false;
            updateLabelsAndButton(false);
        }

        if(e.getSource() == BStart){
            f.dispose(); // Exit Frame
            Opening(); // For loading design

            // Timer to open the JOptionPane
            try {
                Thread.sleep(200);
            } catch (Exception ex) {
                System.out.println();
            }
            FeaturesOfActivity(); // Features of my Activity
            DemoVehicles main = new DemoVehicles(); // Calling the Main Class ( object )
            main.MainOutput(); // The main activity
        }

        if(e.getSource() == BStudName) {
            showStudentName();
        }

        if(e.getSource() == BExit) {
            if (check) {
                JOptionPane.showMessageDialog(null,
                                               "PLEASE TURN IT OFF!"); // You cant exit if the frame is still ON
            } else {
                f.dispose(); // Exit frame
            }
        }
    }

    // This is the Action of Button On and Off
    private void updateLabelsAndButton(boolean isOn) {
        LOn.setVisible(isOn);
        LOff.setVisible(!isOn);
        LTitle.setVisible(isOn);

        // BStart Update
        if (isOn) {
            PDcRedRight.setBackground(Color.GREEN);
            PDcRedRight.setBorder(borderBlack);
            PDcRedLeft.setBackground(Color.GREEN);
            PDcRedLeft.setBorder(borderBlack);

            BStudName.setEnabled(true);
            BStudName.setBorder(borderBlack);
            BStudName.setForeground(Color.BLACK);
            BStudName.setBackground(new Color(0, 163, 168));

            BStart.setEnabled(true);
            BStart.setBorder(borderBlack);
            BStart.setForeground(Color.BLACK);
            BStart.setBackground(new Color(0, 163, 168));
        } else {
            PDcRedRight.setBackground(Color.DARK_GRAY);
            PDcRedLeft.setBackground(Color.DARK_GRAY);

            BStudName.setEnabled(false);
            BStudName.setBorder(borderBlack);
            BStudName.setBackground(Color.DARK_GRAY);

            BStart.setEnabled(false);
            BStart.setBorder(borderBlack);
            BStart.setBackground(Color.DARK_GRAY);
        }
    }

    // FRAME
    private  JFrame CreateFrame() {
        JFrame MainFrame = new JFrame("SATORRE-ACT7Lab");
        MainFrame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        MainFrame.setResizable(false);
        MainFrame.setBounds(10, 10, 400, 632);
        MainFrame.setLayout(null);
        MainFrame.setLocationRelativeTo(null);

        return MainFrame;
    }

    // PANEL
    private JPanel CreatePanel(Border border,Color color, int x, int y, int width, int height){
        JPanel Create = new JPanel();
        Create.setBackground(color);
        Create.setBorder(border);
        Create.setLayout(null);
        Create.setBounds(x, y, width, height);

        return Create;
    }

    // LABEL
    private JLabel CreateLabel(String type, Color color, boolean visible, int x ,int y, int width, int height){
        JLabel CreateL = new JLabel(type);
        CreateL.setForeground(color);
        CreateL.setVisible(visible);
        CreateL.setBounds(x, y,width,height);

        return CreateL;
    }

    // BUTTON
    private JButton CreateButton(String type,int FontSize, Border border,Color color, int x, int y, int width, int height) {
        JButton Create = new JButton(type);
        Create.setFont(new Font("Arial", Font.BOLD, FontSize));
        Create.setBackground(color);
        Create.setForeground(Color.BLACK);
        Create.setCursor(new Cursor(Cursor.HAND_CURSOR));
        Create.setBorder(border);
        Create.addActionListener(this);
        Create.setFocusable(false);
        Create.setBounds(x, y, width,height);

        return Create;
    }

    // ADD COMPONENTS
    private void AddNeedComponents() {
        // ADD to Panel Design Color red on the Right Side
        PDredRight.add(PDcRedRight);
        PDredLeft.add(PDcRedLeft);

        // ADD to Heading Title for name and ACTIVITY 7
        pUpper.add(LTitleName);
        pUpper.add(LTitle);

        // ADD to pDisplayOnOff
        pDisplayOnOff.add(LOff);
        pDisplayOnOff.add(LOn);

        // ADD to pOnOff
        pOnOff.add(pDisplayOnOff);
        pOnOff.add(LPower);

        // ADD to Panel Center
        pCenter.add(BStudName);
        pCenter.add(BStart);
        pCenter.add(PDcBlue);
        pCenter.add(PDcGreen);
        pCenter.add(PDcRED);
        pCenter.add(PDcBlack);

        // ADD to Frame
        f.add(BOff);
        f.add(BOn);
        f.add(BExit);
        f.add(PDredRight);
        f.add(PDredLeft);
        f.add(pOnOff);
        f.add(pCenter);
        f.add(pUpper);
        f.add(pBackBorder);
    }

    // MY NAME
    private void showStudentName() {
        LTitle.setVisible(false);
        LTitleName.setVisible(true);
        JOptionPane.showMessageDialog(null, "LANCE TIMOTHY B. SATORRE");
        LTitleName.setVisible(false);
        LTitle.setVisible(true);
    }

    // LOADING DESIGN..
    private void Opening() {
        int loading;
        System.out.println("\n\nOPENING FILE: ");

        for (int i = 0; i <= 100; i += 10) {
            try {
                Thread.sleep(200);
            } catch (Exception d) {
                System.out.println("Error");
            }

            loading = i;
            System.out.print("\r[");
            for (int j = 0; j <= i / 2; j++) {
                System.out.print("|");
            }
            for (int j = i / 2; j < 50; j++) {
                System.out.print(" ");
            }
            System.out.print("] " + loading + "%");
        }
        System.out.println("\nFILE OPENED!\n");


    }

    // FEATURES OF MY ACTIVITY
    private void FeaturesOfActivity() {
        System.out.println("+=------------------------------------------------------=+\n" +
                            " FEATURES: \n"+
                            " -> YOU CAN BACK TO THE SAILBOAT PRICE\n"+
                            " -> YOU CAN CHANGE YOUR PRICE OF SAILBOAT\n"+
                            " -> YOU CAN CANCEL THE SAILBOAT\n"+
                            " -> YOU CAN CANCEL THE BICYCLE\n"+
                            " -> IF YOU'RE DONE, YOU CAN TRY AGAIN THE PROGRAM\n"+
                            "\n ( Press CANCEL to Back and Cancel Vehicle )\n" +
                          "+=------------------------------------------------------=+\n");
    }
}
