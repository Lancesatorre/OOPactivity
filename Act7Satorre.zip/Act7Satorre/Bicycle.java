package Act7Satorre;

import javax.swing.*;
public class Bicycle extends Vehicle{
    // Properties
    private boolean check; // for Condition of toString
    public Bicycle() {
        super("a person", 2);
    }

    // Method 1: Override set Price of Bicycle price
    @Override
    public void setPrice() {
        String entry;

        final int MAX = 4000; // Max price
        boolean checks = true; // Enter the while loop
        while (checks) {
            try {
                entry = JOptionPane.showInputDialog(null,"Enter Bicycle price ");
                if( entry == null) {
                    System.out.println(" --> CANCEL BICYCLE.");
                    check = false; // Apply toString condition
                    break;
                } else {
                    check = true; // Apply toString condition
                }
                price = Integer.parseInt(entry);
                if(price < 500 || price > 4000) {
                    JOptionPane.showMessageDialog(null,
                            "Price is out of Range!\n Min: $500\n Max: $4,000 ");
                } else {
                    System.out.printf(" --> BICYCLE PRICE: $%,d\n", price);
                    checks = false;
                }
            } catch (NumberFormatException  e) {
                JOptionPane.showMessageDialog(null, "   INVALID INPUT ");
            }
        }
        if (price > MAX)
            price = MAX;

    }

    // Method 2: Override toString
    @Override
    public String toString() {
        if (check) {
            return String.format("- The bicycly is powered by %s, it has %d wheels and costs $%,d",
                    getPowerSource(), getWheels(), getPrice());
        } else {
            return ("- BICYCLE HAS BEEN CANCELED!!");
        }
    }
}

