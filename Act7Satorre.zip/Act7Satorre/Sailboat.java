package Act7Satorre;

import javax.swing.*;
import java.awt.*;

public class Sailboat extends Vehicle{
    // Properties
    private int length;
    private boolean checkStatus = true; // For Condition of toString
    private boolean newValue = false; // Condition of Sailboat Price
    public Sailboat() {
        super("wind",0);
        if (getPrice() == 0) {
            checkStatus = false; // if price is canceled
        } else{
            setLength(); // if price have value and it will continue for setLength
        }
    }

    // Method 1: set Length of Sailboat
    public void setLength() {
        String entry;

        boolean checks = true; // enter while loop
        while (checks) {
            try {
                entry = JOptionPane.showInputDialog(null,"Enter sailboat length in feet");
                if( entry == null) {
                    System.out.println(" --> YOU BACK TO SAILBOAT PRICE\n (SAILBOAT PRICE HAS BEEN RESET)");
                    newValue = true; // this is for display the new value of sailboat
                    setPrice(); // this is the input new value of price , this will apply if user press cancel button ( back to price )
                    if(getPrice() == 0) {
                        checkStatus = false; // if the user cancel again the setprice method, and it will cancel the sailboat.
                        break;
                    } else {
                        continue; // if user input a new value of price , and it back to setLength method
                    }
                }
                length = Integer.parseInt(entry);
                System.out.println(" --> SAILBOAT LENGTH: " + length);
                checks = false; // exit while loop
            } catch (NumberFormatException  e) {
                JOptionPane.showMessageDialog(null, " INTEGERS ONLY! ");
            }
        }
    }

    // Method 2: get Length of Sailboat
    public int getLength(){
        return length;
    }

    // Method 3: Override the setPrice to set the Sailboat price
    @Override
    public void setPrice() {
        price = 0; // reset value of price
        String entry;

        final int MAX = 100000; // Max price
        boolean check = true; // enter while loop
        while (check) {
            try {
                entry = JOptionPane.showInputDialog(null,"Enter sailboat price ");
                if( entry == null) {
                    System.out.println(" --> CANCEL SAILBOAT.");
                    break;
                }
                price = Integer.parseInt(entry);
                if(price < 50000 || price > 100000) {
                    JOptionPane.showMessageDialog(null,
                            "Price is out of Range!\n Min: $50,000\n Max: $100,000 "); // this is for minimum price
                } else {
                    System.out.printf(" --> " + (newValue ? "NEW " : "") + "SAILBOAT PRICE: $%,d\n", price);
                    check = false; // exit while loop
                }
            } catch (NumberFormatException  e) {
                JOptionPane.showMessageDialog(null, "  INVALID INPUT ");
            }
        }
        if (price > MAX)
            price = MAX;
    }

    // Method 4: Override toString
    @Override
    public String toString() {
        if(checkStatus) {
            return String.format("- The %d foot sailboat is powered by %s, it has %d wheels and costs $%,d",
                    getLength(), getPowerSource(), getWheels(), getPrice());
        }else {
            return("- SAILBOAT HAS BEEN CANCELED!!");
        }
    }
}
