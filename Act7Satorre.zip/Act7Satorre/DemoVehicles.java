package Act7Satorre;

// THIS IS MAIN, RUN HERE <<<
import javax.swing.*;
public class DemoVehicles {
    public static void main(String[] args) {
     new GUIFrame();
    }

    // MAIN ACTIVITY
    public void MainOutput() {
        do {
            Sailboat aBoat = new Sailboat();
            Bicycle aBike = new Bicycle();

            JOptionPane.showMessageDialog(null, "\nVehicle description:\n" +
            aBoat.toString() + "\n" + aBike.toString());

            int response = JOptionPane.showConfirmDialog(
                    null,
                    "Do you want to try again?",
                    "",
                    JOptionPane.YES_NO_OPTION);

            if (response == JOptionPane.NO_OPTION) {
                break;
            } else {
                System.out.println("\n+=-----------------------------------=+");
                System.out.printf(" --> NEW ATTEMPT \n");
            }
        }while(true);
        System.out.println("\n\n --> EXIT PROGRAM...");
    }
}
